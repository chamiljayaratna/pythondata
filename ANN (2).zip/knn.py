from __future__ import division
import numpy as np 
import matplotlib.pyplot as mplot 
import pandas
col=['X','Y','Z']
data = pandas.read_csv('data.csv',names=col)
x = data.X.tolist()
y = data.Y.tolist()
z = data.Z.tolist()
x.pop(0)
y.pop(0)
z.pop(0)

#plots results            
mplot.scatter(x, y) 
mplot.show()
